# Architecture Notes

## Goal
Resolve repetitive commerce support work autonomously while keeping irreversible or high-risk actions human-in-the-loop.

## Components

```mermaid
flowchart LR
  T[Open support ticket] --> A[Autonomous Support Agent]
  A --> M[Decision Model]
  M --> A
  A --> P[Safety Policy]
  A --> X[Tool Layer]
  X --> O[(Orders / Postgres)]
  X --> S[Shipping provider]
  X --> C[Customer messaging]
  X --> H[Human escalation queue]
  A --> L[(Action log + metrics)]
```

## Why a tool boundary?
The model never directly mutates commerce data. Every side effect is executed through a typed tool that can enforce policy, authorization, logging, idempotency, and evaluation.

## Evaluation plan
Track at least:
- autonomous resolution rate,
- false-resolution rate,
- escalation precision,
- average steps per ticket,
- median resolution time,
- customer satisfaction,
- credit/recovery cost,
- estimated human minutes saved.

A production rollout should start in shadow mode, then read-only mode, then limited side effects behind explicit thresholds.
