-- PostgreSQL schema matching the repository boundary used by the agent.
CREATE TABLE customers (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE orders (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  total_usd NUMERIC(10,2) NOT NULL CHECK (total_usd >= 0),
  status TEXT NOT NULL CHECK (status IN ('processing','shipped','delivered','cancelled')),
  promised_date TIMESTAMPTZ NOT NULL,
  carrier TEXT,
  tracking_number TEXT,
  artwork_status TEXT NOT NULL CHECK (artwork_status IN ('approved','needs_review','rejected'))
);

CREATE TABLE support_tickets (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  order_id TEXT NOT NULL REFERENCES orders(id),
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE agent_actions (
  id BIGSERIAL PRIMARY KEY,
  ticket_id TEXT NOT NULL REFERENCES support_tickets(id),
  tool_name TEXT NOT NULL,
  reason TEXT NOT NULL,
  args JSONB NOT NULL DEFAULT '{}'::jsonb,
  result JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX agent_actions_ticket_id_created_at_idx
  ON agent_actions(ticket_id, created_at);
