import type { AgentContext } from "./types.js";

export interface SafetyPolicy {
  maxAutonomousCreditUsd: number;
  maxOrderValueForAutoResolutionUsd: number;
  maxSteps: number;
}

export const defaultPolicy: SafetyPolicy = {
  maxAutonomousCreditUsd: 15,
  maxOrderValueForAutoResolutionUsd: 150,
  maxSteps: 8,
};

export function requiresHumanReview(context: AgentContext, proposedCreditUsd = 0): string | undefined {
  if (!context.order) return "Order data is unavailable.";
  if (context.order.totalUsd > defaultPolicy.maxOrderValueForAutoResolutionUsd) {
    return `Order value $${context.order.totalUsd.toFixed(2)} exceeds autonomous resolution threshold.`;
  }
  if (proposedCreditUsd > defaultPolicy.maxAutonomousCreditUsd) {
    return `Proposed credit $${proposedCreditUsd.toFixed(2)} exceeds autonomous credit threshold.`;
  }
  return undefined;
}
