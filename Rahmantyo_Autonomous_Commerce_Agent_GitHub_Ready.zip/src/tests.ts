import { AutonomousSupportAgent } from "./agent.js";
import { orders, tickets } from "./fixtures.js";
import { DeterministicPolicyModel } from "./models.js";
import { InMemoryCommerceRepository } from "./repository.js";

function assert(condition: boolean, message: string): void {
  if (!condition) throw new Error(`Assertion failed: ${message}`);
}

async function main(): Promise<void> {
  const repo = new InMemoryCommerceRepository(orders, tickets);
  const agent = new AutonomousSupportAgent(new DeterministicPolicyModel(), repo);

  const delayed = await agent.run(tickets[0]!);
  assert(delayed.status === "resolved", "Delayed shipment should auto-resolve.");
  assert(repo.credits[0]?.amountUsd === 10, "Delayed shipment should receive bounded $10 credit.");

  const artwork = await agent.run(tickets[1]!);
  assert(artwork.status === "escalated", "Artwork needing review should escalate.");

  const highValue = await agent.run(tickets[2]!);
  assert(highValue.status === "escalated", "High-value refund request should escalate.");
  assert(repo.credits.every((credit) => credit.amountUsd <= 15), "No credit may exceed safety threshold.");

  console.log("All tests passed.");
}

await main();
