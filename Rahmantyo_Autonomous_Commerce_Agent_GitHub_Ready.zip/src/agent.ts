import { defaultPolicy } from "./policy.js";
import type { CommerceRepository } from "./repository.js";
import { CommerceTools } from "./tools.js";
import type { AgentContext, AgentRunResult, DecisionModel, Ticket } from "./types.js";

export class AutonomousSupportAgent {
  private readonly tools: CommerceTools;

  constructor(private readonly model: DecisionModel, repo: CommerceRepository) {
    this.tools = new CommerceTools(repo);
  }

  async run(ticket: Ticket): Promise<AgentRunResult> {
    const context: AgentContext = { ticket, notes: [] };
    const actions: AgentRunResult["actions"] = [];

    for (let step = 1; step <= defaultPolicy.maxSteps; step += 1) {
      const action = await this.model.decide(context, actions);
      const result = await this.tools.execute(action, context);
      actions.push({ action, result });

      if (action.tool === "send_customer_reply" && result.ok) {
        return {
          ticketId: ticket.id,
          status: "resolved",
          steps: step,
          actions,
          customerReply: String(result.data?.message ?? ""),
          estimatedHumanMinutesSaved: 6,
        };
      }

      if (action.tool === "escalate" && result.ok) {
        return {
          ticketId: ticket.id,
          status: "escalated",
          steps: step,
          actions,
          escalationReason: String(result.data?.reason ?? action.reason),
          estimatedHumanMinutesSaved: 2,
        };
      }

      if (!result.ok && result.data?.requiresHumanReview === true) {
        const escalation = {
          tool: "escalate" as const,
          args: { reason: result.summary },
          reason: "A tool-side safety policy blocked autonomous action.",
        };
        const escalationResult = await this.tools.execute(escalation, context);
        actions.push({ action: escalation, result: escalationResult });
        return {
          ticketId: ticket.id,
          status: "escalated",
          steps: step + 1,
          actions,
          escalationReason: result.summary,
          estimatedHumanMinutesSaved: 1,
        };
      }
    }

    return {
      ticketId: ticket.id,
      status: "failed",
      steps: defaultPolicy.maxSteps,
      actions,
      escalationReason: "Maximum agent steps reached without a terminal action.",
      estimatedHumanMinutesSaved: 0,
    };
  }
}
