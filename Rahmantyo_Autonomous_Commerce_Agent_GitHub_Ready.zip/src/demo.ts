import { AutonomousSupportAgent } from "./agent.js";
import { orders, tickets } from "./fixtures.js";
import { DeterministicPolicyModel } from "./models.js";
import { InMemoryCommerceRepository } from "./repository.js";

const repo = new InMemoryCommerceRepository(orders, tickets);
const agent = new AutonomousSupportAgent(new DeterministicPolicyModel(), repo);

for (const ticket of await repo.listOpenTickets()) {
  const result = await agent.run(ticket);
  console.log(JSON.stringify(result, null, 2));
}

const resolved = repo.replies.length;
const escalated = repo.escalations.length;
const credits = repo.credits.reduce((sum, item) => sum + item.amountUsd, 0);

console.log("\n=== Portfolio demo metrics ===");
console.log(JSON.stringify({ tickets: tickets.length, resolved, escalated, creditsIssuedUsd: credits }, null, 2));
