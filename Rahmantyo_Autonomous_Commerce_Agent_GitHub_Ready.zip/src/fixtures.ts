import type { Order, Ticket } from "./types.js";

export const orders: Order[] = [
  {
    id: "ORD-1001",
    customerId: "CUS-01",
    totalUsd: 48,
    status: "shipped",
    promisedDate: "2026-09-18T17:00:00Z",
    carrier: "UPS",
    trackingNumber: "1Z-DEMO-1001",
    artworkStatus: "approved",
  },
  {
    id: "ORD-1002",
    customerId: "CUS-02",
    totalUsd: 92,
    status: "processing",
    promisedDate: "2026-09-25T17:00:00Z",
    artworkStatus: "needs_review",
  },
  {
    id: "ORD-1003",
    customerId: "CUS-03",
    totalUsd: 420,
    status: "processing",
    promisedDate: "2026-09-26T17:00:00Z",
    artworkStatus: "approved",
  },
];

export const tickets: Ticket[] = [
  {
    id: "TCK-01",
    customerId: "CUS-01",
    orderId: "ORD-1001",
    message: "My order is late. Can you check the tracking and help?",
    createdAt: "2026-09-21T08:00:00Z",
  },
  {
    id: "TCK-02",
    customerId: "CUS-02",
    orderId: "ORD-1002",
    message: "The proof says my artwork needs review. What happens next?",
    createdAt: "2026-09-21T08:10:00Z",
  },
  {
    id: "TCK-03",
    customerId: "CUS-03",
    orderId: "ORD-1003",
    message: "Please refund this order.",
    createdAt: "2026-09-21T08:20:00Z",
  },
];
