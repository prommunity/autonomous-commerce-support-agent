import type { CommerceRepository } from "./repository.js";
import { requiresHumanReview } from "./policy.js";
import type { AgentAction, AgentContext, TicketKind, ToolResult } from "./types.js";

export class CommerceTools {
  constructor(private readonly repo: CommerceRepository) {}

  async execute(action: AgentAction, context: AgentContext): Promise<ToolResult> {
    switch (action.tool) {
      case "get_order": {
        const order = await this.repo.getOrder(context.ticket.orderId);
        if (!order) return { ok: false, summary: "Order not found." };
        context.order = order;
        return { ok: true, summary: `Loaded order ${order.id}.`, data: { order } };
      }
      case "classify_ticket": {
        const text = context.ticket.message.toLowerCase();
        let kind: TicketKind = "unknown";
        if (/late|delay|tracking|where.*order|shipping/.test(text)) kind = "shipping_delay";
        else if (/artwork|proof|resolution|cut line|bleed/.test(text)) kind = "artwork_issue";
        else if (/refund|money back|credit/.test(text)) kind = "refund_request";
        context.ticketKind = kind;
        return { ok: true, summary: `Classified ticket as ${kind}.`, data: { kind } };
      }
      case "check_shipping": {
        if (!context.order) return { ok: false, summary: "Load the order first." };
        const promised = new Date(context.order.promisedDate).getTime();
        const ticketTime = new Date(context.ticket.createdAt).getTime();
        const late = ticketTime > promised && context.order.status !== "delivered";
        return {
          ok: true,
          summary: late ? "Shipment is past the promised date." : "Shipment is not past the promised date.",
          data: {
            late,
            carrier: context.order.carrier ?? null,
            trackingNumber: context.order.trackingNumber ?? null,
          },
        };
      }
      case "check_artwork": {
        if (!context.order) return { ok: false, summary: "Load the order first." };
        return {
          ok: true,
          summary: `Artwork status is ${context.order.artworkStatus}.`,
          data: { artworkStatus: context.order.artworkStatus },
        };
      }
      case "issue_credit": {
        if (!context.order) return { ok: false, summary: "Load the order first." };
        const amount = Number(action.args.amountUsd ?? 0);
        const reason = String(action.args.reason ?? "Service recovery");
        const reviewReason = requiresHumanReview(context, amount);
        if (reviewReason) return { ok: false, summary: reviewReason, data: { requiresHumanReview: true } };
        await this.repo.recordCredit(context.order.id, amount, reason);
        return { ok: true, summary: `Issued $${amount.toFixed(2)} account credit.` };
      }
      case "send_customer_reply": {
        const message = String(action.args.message ?? "").trim();
        if (!message) return { ok: false, summary: "Reply message is empty." };
        await this.repo.recordReply(context.ticket.id, message);
        return { ok: true, summary: "Customer reply sent.", data: { message } };
      }
      case "escalate": {
        const reason = String(action.args.reason ?? action.reason);
        await this.repo.recordEscalation(context.ticket.id, reason);
        return { ok: true, summary: "Ticket escalated to a human.", data: { reason } };
      }
    }
  }
}
