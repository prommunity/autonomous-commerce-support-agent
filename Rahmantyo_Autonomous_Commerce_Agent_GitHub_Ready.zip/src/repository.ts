import type { Order, Ticket } from "./types.js";

export interface CommerceRepository {
  getOrder(orderId: string): Promise<Order | undefined>;
  listOpenTickets(): Promise<Ticket[]>;
  recordCredit(orderId: string, amountUsd: number, reason: string): Promise<void>;
  recordReply(ticketId: string, message: string): Promise<void>;
  recordEscalation(ticketId: string, reason: string): Promise<void>;
}

export class InMemoryCommerceRepository implements CommerceRepository {
  readonly credits: Array<{ orderId: string; amountUsd: number; reason: string }> = [];
  readonly replies: Array<{ ticketId: string; message: string }> = [];
  readonly escalations: Array<{ ticketId: string; reason: string }> = [];

  constructor(private readonly orders: Order[], private readonly tickets: Ticket[]) {}

  async getOrder(orderId: string): Promise<Order | undefined> {
    return this.orders.find((order) => order.id === orderId);
  }

  async listOpenTickets(): Promise<Ticket[]> {
    return [...this.tickets];
  }

  async recordCredit(orderId: string, amountUsd: number, reason: string): Promise<void> {
    this.credits.push({ orderId, amountUsd, reason });
  }

  async recordReply(ticketId: string, message: string): Promise<void> {
    this.replies.push({ ticketId, message });
  }

  async recordEscalation(ticketId: string, reason: string): Promise<void> {
    this.escalations.push({ ticketId, reason });
  }
}
