import type { AgentAction, AgentContext, DecisionModel } from "./types.js";

function previousTools(history: Array<{ action: AgentAction }>): Set<string> {
  return new Set(history.map((entry) => entry.action.tool));
}

export class DeterministicPolicyModel implements DecisionModel {
  async decide(context: AgentContext, history: Array<{ action: AgentAction }>): Promise<AgentAction> {
    const used = previousTools(history);

    if (!used.has("get_order")) {
      return { tool: "get_order", args: {}, reason: "Need verified order context before taking action." };
    }
    if (!used.has("classify_ticket")) {
      return { tool: "classify_ticket", args: {}, reason: "Need to identify the support workflow." };
    }
    if (!context.order) {
      return { tool: "escalate", args: { reason: "Order could not be loaded." }, reason: "Cannot safely act without order data." };
    }

    if (context.order.totalUsd > 150) {
      return {
        tool: "escalate",
        args: { reason: "High-value order requires human review." },
        reason: "Policy prevents autonomous resolution for high-value orders.",
      };
    }

    if (context.ticketKind === "shipping_delay") {
      if (!used.has("check_shipping")) {
        return { tool: "check_shipping", args: {}, reason: "Verify whether the shipment is actually late." };
      }
      if (!used.has("issue_credit")) {
        return {
          tool: "issue_credit",
          args: { amountUsd: 10, reason: "Late shipment service recovery" },
          reason: "A small bounded credit is allowed for a verified delay.",
        };
      }
      return {
        tool: "send_customer_reply",
        args: {
          message: `Thanks for reaching out about order ${context.order.id}. I confirmed the shipment is delayed. I added a $10 account credit for the inconvenience. Your tracking number is ${context.order.trackingNumber ?? "not available yet"}.`,
        },
        reason: "The issue is resolved and the customer should receive a concise status update.",
      };
    }

    if (context.ticketKind === "artwork_issue") {
      if (!used.has("check_artwork")) {
        return { tool: "check_artwork", args: {}, reason: "Check the current artwork review state." };
      }
      if (context.order.artworkStatus === "needs_review") {
        return {
          tool: "escalate",
          args: { reason: "Artwork requires specialist review before production." },
          reason: "Visual production decisions are intentionally kept human-in-the-loop.",
        };
      }
      return {
        tool: "send_customer_reply",
        args: { message: `Your artwork for order ${context.order.id} is marked ${context.order.artworkStatus}. No manual intervention is currently required.` },
        reason: "Provide the verified artwork status.",
      };
    }

    if (context.ticketKind === "refund_request") {
      return {
        tool: "escalate",
        args: { reason: "Refund requests require human approval in this demo policy." },
        reason: "Financial reversal is outside autonomous authority.",
      };
    }

    return {
      tool: "escalate",
      args: { reason: "Unrecognized request type." },
      reason: "Unknown intents should not trigger autonomous side effects.",
    };
  }
}

export class OpenAICompatibleJsonModel implements DecisionModel {
  constructor(
    private readonly apiKey: string,
    private readonly model: string,
    private readonly baseUrl = "https://api.openai.com/v1",
  ) {}

  async decide(context: AgentContext, history: Array<{ action: AgentAction }>): Promise<AgentAction> {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        model: this.model,
        temperature: 0,
        response_format: { type: "json_object" },
        messages: [
          {
            role: "system",
            content:
              "You are a commerce support agent planner. Return JSON with keys tool, args, reason. Allowed tools: get_order, classify_ticket, check_shipping, check_artwork, issue_credit, send_customer_reply, escalate. Never issue more than $15 credit. Escalate uncertain, high-value, refund, or unsafe cases.",
          },
          {
            role: "user",
            content: JSON.stringify({ context, history }, null, 2),
          },
        ],
      }),
    });

    if (!response.ok) throw new Error(`Model request failed: ${response.status}`);
    const payload = (await response.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = payload.choices?.[0]?.message?.content;
    if (!content) throw new Error("Model returned no content.");
    const parsed = JSON.parse(content) as AgentAction;
    return parsed;
  }
}
