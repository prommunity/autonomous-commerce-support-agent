export type TicketKind = "shipping_delay" | "artwork_issue" | "refund_request" | "unknown";
export type ResolutionStatus = "resolved" | "escalated" | "failed";

export interface Ticket {
  id: string;
  customerId: string;
  orderId: string;
  message: string;
  createdAt: string;
}

export interface Order {
  id: string;
  customerId: string;
  totalUsd: number;
  status: "processing" | "shipped" | "delivered" | "cancelled";
  promisedDate: string;
  carrier?: string;
  trackingNumber?: string;
  artworkStatus: "approved" | "needs_review" | "rejected";
}

export interface AgentContext {
  ticket: Ticket;
  order?: Order;
  ticketKind?: TicketKind;
  notes: string[];
}

export type ToolName =
  | "get_order"
  | "classify_ticket"
  | "check_shipping"
  | "check_artwork"
  | "issue_credit"
  | "send_customer_reply"
  | "escalate";

export interface AgentAction {
  tool: ToolName;
  args: Record<string, string | number | boolean>;
  reason: string;
}

export interface ToolResult {
  ok: boolean;
  summary: string;
  data?: Record<string, unknown>;
}

export interface AgentRunResult {
  ticketId: string;
  status: ResolutionStatus;
  steps: number;
  actions: Array<{ action: AgentAction; result: ToolResult }>;
  customerReply?: string;
  escalationReason?: string;
  estimatedHumanMinutesSaved: number;
}

export interface DecisionModel {
  decide(context: AgentContext, history: AgentRunResult["actions"]): Promise<AgentAction>;
}
